module.exports.dirname = __dirname;
module.exports.layouts = {
    all: require('./layouts/all.json'),
    streets: require('./layouts/streets.json')
};
